# Biorhythm Website

Website sederhana untuk menghitung bioritme berdasarkan tanggal lahir dan tanggal target.

## Fitur
- Perhitungan siklus fisik, emosional, dan intelektual
- Tampilan sederhana dan responsif
- Mudah di-deploy ke GitHub Pages

## Cara Menjalankan
1. Download project ini
2. Buka file index.html di browser

## Teknologi
- HTML
- CSS
- JavaScript
