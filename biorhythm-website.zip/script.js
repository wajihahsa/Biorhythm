function calculateBiorhythm() {
  const birthDate = new Date(document.getElementById("birthDate").value);
  const targetDate = new Date(document.getElementById("targetDate").value);

  if (!birthDate || !targetDate) {
    document.getElementById("result").innerText = "Mohon isi semua tanggal.";
    return;
  }

  const diffTime = targetDate - birthDate;
  const days = diffTime / (1000 * 60 * 60 * 24);

  const physical = Math.sin(2 * Math.PI * days / 23);
  const emotional = Math.sin(2 * Math.PI * days / 28);
  const intellectual = Math.sin(2 * Math.PI * days / 33);

  document.getElementById("result").innerHTML = `
    Physical: ${(physical * 100).toFixed(2)}% <br>
    Emotional: ${(emotional * 100).toFixed(2)}% <br>
    Intellectual: ${(intellectual * 100).toFixed(2)}%
  `;
}
